$(function () {
    $('.img__wrap').on('click', function(){
        console.log("Clicou");
        $('#label_browse').click();
    });
});